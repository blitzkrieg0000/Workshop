#!/bin/bash
kubectl delete configmap zookeeperenv
kubectl delete configmap brokerenv
kubectl delete configmap schemaregistryenv
kubectl delete configmap restproxyenv
kubectl delete configmap kafkaconnectenv
kubectl delete configmap ksqldbserverenv
kubectl delete configmap ksqldbcli