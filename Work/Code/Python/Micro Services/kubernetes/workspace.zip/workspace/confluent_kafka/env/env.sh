#!/bin/bash
kubectl create configmap zookeeperenv --from-env-file=env_zookeeper.txt
kubectl create configmap brokerenv --from-env-file=env_broker.txt
kubectl create configmap schemaregistryenv --from-env-file=env_schema_registry.txt
kubectl create configmap restproxyenv --from-env-file=env_restproxy.txt
kubectl create configmap kafkaconnectenv --from-env-file=env_kafkaconnect.txt
kubectl create configmap ksqldbserverenv --from-env-file=env_ksqldbserver.txt
kubectl create configmap ksqldbclienv --from-env-file=env_ksqldbcli.txt